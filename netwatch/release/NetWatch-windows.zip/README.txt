NetWatch is a desktop application for this Windows PC.

1. Unzip this folder anywhere on the PC whose network you want to watch.
2. Double-click NetWatch.exe.
3. Right-click NetWatch.exe and choose "Run as administrator" if you want
   to see who sent a ping, or to pin the router MAC.

It reads this computer's ARP table and ICMP counters. A copy running on
another machine cannot see this PC's local network.
