Play Console listing assets
===========================

App icon (512x512): app-icon-512.png
Feature graphic (1024x500): feature-graphic-1024x500.png

Phone 9:16 1080x1920 (upload 2–8):
  screenshot-phone-portrait-home.png
  screenshot-phone-portrait-official.png
  screenshot-phone-portrait-phishing.png

7-inch tablet 16:9 1920x1080:
  screenshot-tablet7-home.png
  screenshot-tablet7-official.png
  screenshot-tablet7-phishing.png

10-inch tablet 16:9 2560x1440:
  screenshot-tablet10-home.png
  screenshot-tablet10-official.png
  screenshot-tablet10-phishing.png
